export default [
    {
        heading: "BABY IT'S COLD OUTSIDE",
        content : "  Winter's here, and there's nothing dry, dehydrated or atopic skin likes less! Cooling temperatures, increased use of heating and declining humity...",
        image : "testimonial1.png"
    },
    {
        heading: "BABY IT'S COLD OUTSIDE",
        content : "  Winter's here, and there's nothing dry, dehydrated or atopic skin likes less! Cooling temperatures, increased use of heating and declining humity...",
        image : "testimonial2.png"
    },
    {
        heading: "BABY IT'S COLD OUTSIDE",
        content : "  Winter's here, and there's nothing dry, dehydrated or atopic skin likes less! Cooling temperatures, increased use of heating and declining humity...",
        image : "testimonial3.png"
    },
]