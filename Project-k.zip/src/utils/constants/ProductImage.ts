export default [
    {
        image : "product-image1.png"
    },
    {
        image : "product-image2.png"
    }
]