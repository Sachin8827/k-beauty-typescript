export default  [
    {
      title: "HOW TO USE",
      content: "Content for Accordion Item 1",
    },
    {
      title: "INGREDIENTS",
      content: "Content for Accordion Item 2",
    },
    {
      title: "REVIEWS (13)",
      content: "Content for Accordion Item 3",
    },
  ];