
import { useNavigate } from "react-router-dom";

import LoginForm from "../components/auth/LoginForm";

const Login: React.FC = () => {


  return (
    <>
      <LoginForm />
    </>
  );
}
export default Login;
